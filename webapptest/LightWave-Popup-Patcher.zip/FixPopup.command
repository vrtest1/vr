#!/bin/zsh
set -eu
source_dir="${1:-/Applications/NewTek/LightWave3D_2018.0.7}"
lib=bin/libtools.2018.0.7.dylib
original=ec214f9b471ec12f717e508b470638cd0d9fe77f230e100cd41b1d042633c1d8
fixed=0a2b1b59ace298ddd0c2b83915cbd8d3c7445b27f232481d3285fc0d6d775e45
digest() { /usr/bin/shasum -a 256 "$1" | /usr/bin/cut -d ' ' -f 1; }
if [[ ! -f "$source_dir/$lib" || "$(digest "$source_dir/$lib")" != "$original" ]]; then
  print -u2 '対象の Mac 版 LightWave 2018.0.7 が見つからないか、ライブラリが検証済みの版と異なります。'
  exit 1
fi
dest=$(/usr/bin/mktemp -d "$HOME/LightWave-Popup-XXXXXX")
print "作成先 $dest"
/bin/mkdir "$dest/LightWave3D_2018.0.7"
copy="$dest/LightWave3D_2018.0.7"
/usr/bin/rsync -aE --exclude='/uninstall.app' "$source_dir/" "$copy/"
target="$copy/$lib"
[[ -f "$target" && ! -L "$target" && "$(digest "$target")" == "$original" ]]
/usr/bin/perl -e '
  use strict;
  use warnings;
  my $path = shift;
  open(my $file, "+<:raw", $path) or die $!;
  seek($file, 0x9a2e, 0) or die $!;
  # Load NSGraphicsContext and currentContext, then call objc_msgSend.
  my $code = pack("H*", "488b3d5b391c00488b358c2d1c004c8b355db71b0041ffd6") . ("\x90" x 6);
  print {$file} $code or die $!;
  close($file) or die $!;
' "$target"
[[ "$(digest "$target")" == "$fixed" ]] || { print -u2 '出力の検証に失敗しました。'; exit 1; }
print "修正完了。このフォルダ内の Modeler.app または Layout.app を直接起動してください。\n$copy"
