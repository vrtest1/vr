LightWave 2018.0.7 popup menu fix for Mac

This script fixes two issues in Modeler and Layout: popup menus that appear as solid gray rectangles with unreadable entries, and a crash that occurs after choosing a popup entry that opens a panel (for example Gear or Edit Keyboard Shortcuts). The ZIP contains the patch script and instructions. You will need your own licensed installation of LightWave 2018.0.7 for Mac.

Instructions
1. Extract the ZIP. The script expects LightWave in /Applications/NewTek/LightWave3D_2018.0.7 by default.
2. Double-click FixPopup.command. Terminal will show the output folder. Wait for “修正完了” (patch complete).
3. Save any open scenes or objects and quit any running copies of Modeler and Layout. In Finder, open the output folder printed by the script and launch Modeler.app or Layout.app directly from it.
4. Open a menu that previously appeared gray and check that you can read its entries. Also open Gear or Edit Keyboard Shortcuts and check that Modeler does not crash.

Using a different installation folder
Drag FixPopup.command into a Terminal window, type a space, then drag your LightWave3D_2018.0.7 installation folder into the same window and press Return.

How it works
The script checks the library's SHA-256 hash and proceeds only if it matches the verified version. It creates a fresh folder in your home directory, copies your local installation there (excluding the uninstaller), patches the drawing library inside the copy's bin folder, and verifies the result. Two locations are changed: the popup view draws into the current graphics context, and the popup record is no longer freed when the popup closes, so a late redraw cannot read freed memory. This leaves 24 bytes of memory unreleased each time a popup closes. Your original installation remains available. The Hub and existing Dock icons may still launch the original applications.

Tested configuration
Popup menu text was confirmed visible in both Modeler and Layout on an Intel Mac running macOS 26.7.3, and Gear and Edit Keyboard Shortcuts opened without crashing in Modeler. Other configurations have not been verified. To return to the original version, quit the patched application and launch it from the original installation folder.
